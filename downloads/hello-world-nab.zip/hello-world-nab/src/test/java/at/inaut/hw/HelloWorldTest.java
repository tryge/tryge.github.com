package at.inaut.hw;

import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(HelloWorldRunner.class)
public class HelloWorldTest {
	@Test
	public void testInstantiation() {
		new HelloWorldActivity();
	}
}
